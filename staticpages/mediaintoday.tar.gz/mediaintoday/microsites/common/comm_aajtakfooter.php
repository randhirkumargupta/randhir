<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<META name="ROBOTS" content="NOINDEX, NOFOLLOW">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style>
body {margin:0; padding:0;}
#google_ad_footer { margin:20px auto;  border:0px solid #000; text-align:center;}
#footer_menu {  width:90%; border:1px solid #BDD9E5; border-width:1px 0px 1px 0px; margin:0 auto; padding:0;color:#4C4C4C; font-size:11px; font-family:Tahoma; text-align:center; font-weight:bold;}
#footer_menu .moduletable
{border:0px solid #000; width:100%; text-align:center }
#footer_menu a:link,
#footer_menu a:visited,
#footer_menu a:hover { color:#4C4C4C; text-decoration:none; line-height:22px; }
#footer_menu span { line-height:16px; margin:0 15px;}
#copyrights
{float:left; padding:10px 0;  font:normal 11px arial; color:#4B4B4B; text-align:center; width:100%; border:0px solid #000;}
#copyrights a
{text-decoration:none; color:#022F59; }

#copyrights a:hover
{text-decoration:underline; }

#itgd_group_links
{border:0px solid #000; margin:0 auto 15px auto; width:99%; font:normal 11px arial; color:#6277A4; line-height:18px; text-align:center; }

#itgd_group_links b
{width:auto; font:bold 11px Arial; color:#E31D36; border:0px solid #000; margin:0; line-height:18px; }
#itgd_group_links strong
{color:#494949; margin:0 0 0 5px;}
#itgd_group_links a
{text-decoration:none; color:#6277A4; margin:0 5px;}
#itgd_group_links a:hover
{text-decoration:underline; }

</style>
</head>

<body>
<div id="itgd_group_links">
     Publications:</strong> <a href="http://indiatoday.intoday.in" target="_blank">India Today</a> | <a href="http://subscriptions.intoday.in/subscriptions/itoday/ith_offer.jsp?source=website" target="_blank">India Today - Hindi</a> | <a href="http://businesstoday.intoday.in" target="_blank">Business Today</a> | <a href="http://cosmo.intoday.in/cosmopolitan/index.jsp" target="_blank">Cosmopolitan</a> | <a href="http://menshealth.intoday.in/" target="_blank">Men's Health</a> | <a href="http://www.wonderwoman.in" target="_blank">Wonder Woman</a> | <a href="http://moneytoday.intoday.in" target="_blank">Money Today</a> | <a href="http://preventionindia.in/issue.html" target="_blank">Prevention</a> | <a href="http://www.rd-india.com/newsite/home/home.asp" target="_blank">Reader's Digest</a> | <a href="http://www.indiatodaygroup.com/goodhouse/issue.html" target="_blank">Good Housekeeping</a> |<a href="http://subscriptions.digitaltoday.in/subscriptions/time/subscription.html" target="_blank">Time</a> |<a href="http://www.hbrsasia.org" target="_blank">Harvard Business Review</a> | <a href="http://www.gadgetsngizmos.in" target="_blank">Gadgets &amp; Gizmos</a>
      <strong>Web:</strong> <a href="http://www.dailyo.in/" target="_blank" title="Dailyo">Dailyo</a> | <a href="http://www.ichowk.in/" target="_blank" title="Ichowk">Ichowk </a> | <a href="http://www.pakwangali.in/" target="_blank" title="Pakwangali">Pakwangali</a>      
   
      <strong>Television:</strong> <a href="http://aajtak.intoday.in" target="_blank">Aaj Tak</a>| <a href="http://indiatoday.intoday.in" target="_blank">India Today</a>  <strong>Radio:</strong> <a href="http://oyefm.in/" target="_blank">Ishq 104.8FM</a> 
     
     <strong>Education:</strong> <a href="http://www.vasantvalley.org/vasantvalley/default.shtml" target="_blank">Vasant  Valley</a> | <a href="http://learntoday.in/" target="_blank">Online Courses</a> | <a href="http://ulearntoday.com" target="_blank">U Learn Today</a> | <a href="http://education.intoday.in/" target="_blank">India Today Education</a> | <a href="http://aajtak.intoday.in/tvtmi" target="_blank">ITMI</a>
      
      <strong>Online Shopping:</strong> <a href="http://www.bagittoday.com/" target="_blank">Bag It Today</a> | <a href="http://www.indiatodaydiaries.com/" target="_blank">India Today Diaries</a> <strong>Events:</strong> <a href="http://agenda.aajtak.in" target="_blank">Agenda Aajtak</a> | <a href="http://www.indiatodayconclave.com" target="_blank">India Today Conclave</a> | <a href="http://indiatoday.in/womansummit/index.php" target="_blank">India Today Woman's Summit</a> | <a href="http://www.indiatoday.in/youthsummit" target="_blank">India Today Youth Summit</a> | <a href="http://indiatoday.intoday.in/state-of-the-states/2015/" target="_blank">State Of The States Conclave</a> | <a href="http://indiatoday.intoday.in/educationsummit/" target="_blank">India Today Education Summit</a> <strong>Music:</strong> <a href="http://www.music-today.com" target="_blank">Music Today</a> <strong>Printing:</strong> <a href="http://www.thomsonpress.com" target="_blank">Thomson Press</a> 
<strong>Welfare:</strong> <a href="http://www.caretoday.in" target="_blank">Care Today</a> <strong>B2B Marketplace:</strong> <a href="http://www.indiabizsource.com" target="_blank">Indiabizsource</a> | <strong>Useful Links :</strong> <a href="http://aajtak.intoday.in/partners.php" target="_blank">Partners</a> | <a href='http://aajtak.intoday.in/prnewswire/prnewswire.html' target="_blank"><strong>Press Releases</strong></a> | <strong>Syndications:</strong> <a href="http://www.indiatodayimages.com/" target="_blank">India Today Images</a> 
| <strong>Distribution:</strong> <a href="http://aajtak.intoday.in/distribution/index.php" target="_blank">Rate Card </a> | <a href="/staticpages/mediaintoday/aajtak/images/das_application/DAS-Application-form.pdf" target="_blank">DAS Application form</a> |<br />
 <a href="http://aajtak.intoday.in/distribution/das_phase_three.php" target="_blank">Contact persons for DAS phase III </a>

</div>











<div id="footer_menu">
        <div class="moduletable">
			<a href="http://www.indiatodaygroup.com/new-site/television.html" target="_blank" class="mainlevel">ABOUT US</a><span class="mainlevel">|</span><a href="http://www.indiatodaygroup.com/new-site/aajtak.html" target="_blank" class="mainlevel">CONTACT US</a><span class="mainlevel">|</span><a href="#" onclick="window.open('http://specials.indiatoday.com/specials/popup/advertisewithus.htm','aws','width=506,height=167,left='+(screen.availWidth/2-253)+',top='+(screen.availHeight/2-91)+'');return false;">ADVERTISE WITH US</a>
<span class="mainlevel">|</span><a href="http://aajtak.intoday.in/complain_redressal.php" target="_blank" class="mainlevel">COMPLAINT REDRESSAL </a><span class="mainlevel">|</span><a href="http://www.wecare24x7.in/" target="_blank" class="mainlevel">WE CARE</a><span class="mainlevel">|</span><a href="http://specials.indiatoday.com/common/privacypolicy/privacy.phtml" target="_blank" class="mainlevel">PRIVACY POLICY</a><span class="mainlevel">|</span><a href="http://specials.indiatoday.com/common/termsandconditions.phtml" target="_blank" class="mainlevel">TERMS AND CONDITIONS</a></div></div><div id="copyrights">Copyright &copy; 2017 Living Media India Limited. For
reprint rights: <a href="http://www.syndicationstoday.com/" target="_blank">Syndications Today.</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
</body>
</html>
